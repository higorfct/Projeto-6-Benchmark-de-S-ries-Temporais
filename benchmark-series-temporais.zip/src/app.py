# Código da aplicação em Gradio ou Streamlit
