# Métricas e gráficos de avaliação
