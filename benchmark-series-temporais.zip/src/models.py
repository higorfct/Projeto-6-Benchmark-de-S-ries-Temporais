# Funções para treinar modelos ARIMA, LSTM, Prophet, etc.
