# Funções de pré-processamento dos dados
